require({cache:{
'url:epi-ecf-ui/contentediting/editors/templates/GridWithDropContainer.html':"﻿<div class=\"epi-grid--with-container\">\n    <div class=\"push-padding--bottom\" data-dojo-attach-point=\"commandTargetNode\"></div>\n    <div class=\"epi-editor-overlay\" data-dojo-attach-point=\"overlayDnd\">\n        <div data-dojo-attach-point=\"gridNode\"></div>\n        <div data-dojo-attach-point=\"dropContainer\" class=\"epi-content-area-actionscontainer\"></div>\n    </div>\n</div>\n"}});
﻿define("epi-ecf-ui/contentediting/editors/_GridWithDropContainerMixin", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/dom-class",
    "dojo/dom-style",
    "dojo/topic",
    "epi/shell/dnd/Target",
    "epi-cms/contentediting/editors/_TextWithActionLinksMixin",
    "./LinkEditorDndMixin",
    "dojo/text!./templates/GridWithDropContainer.html"
], function(
    declare,
    lang,
    aspect,
    domClass,
    domStyle,
    topic,
    Target,
    _TextWithActionLinksMixin,
    LinkEditorDndMixin,
    template
){
    return declare([_TextWithActionLinksMixin, LinkEditorDndMixin], {

        templateString: template,

        gridOverlayClass: "epi-grid-dnd-overlay",

        resources: null,

        buildRendering: function () {
            this.inherited(arguments);
            if (this.readOnly){
                domStyle.set(this.dropContainer, "display", "none");
            } else {
                this.setupActionLinks(this.dropContainer);
            }
            var dndTarget = new Target(this.dropContainer, {
                accept: this.allowedDndTypes,
                insertNodes: function () { }
            });

            this.own(dndTarget,
                    aspect.after(dndTarget, "onDropData", lang.hitch(this, function (dndData, source, nodes, copy) {
                        this.onDndDrop(dndData, source, nodes, copy);
            }), true));

            this.setupDndActions(dndTarget, "checkAcceptance");
        },

        getTemplateString: function () {
            // summary:
            //      The template string for drop area
            // tags:
            //      protected

            return {
                templateString: this.resources.drophere,
                actions: this.resources.actions
            };
        },

        executeAction: function (actionName) {
            // summary:
            //      Called when [entries] link clicked
            // tags:
            //      public override

            topic.publish("/epi/layout/pinnable/tools/toggle", true);
        },

        _setupDnD: function () {
            // summary:
            //      Set up the dnd on the grid.
            // tags:
            //      private
            this.inherited(arguments);
            var dndSource = this.grid.dndSource;
            this.setupDndActions(dndSource, "checkAcceptance");
            this.own(aspect.after(dndSource, "onDndStart", lang.hitch(this, function (source, nodes, copy) {
                var accepted = dndSource.accept && dndSource.checkAcceptance(source, nodes);
                domClass[accepted ? "add" : "remove"](this.overlayDnd, this.gridOverlayClass);
            }), true));
        },

        _setupGrid: function(){
            this.inherited(arguments);
            this.styleGrid();
        },

        styleGrid: function(){
            this._setGridHeight();
            this._setGridHeaderFont();
        },

        _setGridHeight: function(){
            domClass.add(this.gridNode, "epi-grid-max-height--300");
        },

        _setGridHeaderFont: function(){
            domClass.add(this.gridNode, "epi-plain-grid--small-header-font");
        }
    });

});