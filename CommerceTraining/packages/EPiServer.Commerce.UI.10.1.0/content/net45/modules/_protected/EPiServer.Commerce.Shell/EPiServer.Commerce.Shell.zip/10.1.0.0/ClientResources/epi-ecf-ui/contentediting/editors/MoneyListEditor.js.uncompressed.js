﻿define("epi-ecf-ui/contentediting/editors/MoneyListEditor", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/currency",
    "dojo/keys",
    "dojo/store/Memory",
    "dojo/string",
// dijit
    "dijit/_KeyNavContainer",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetBase",
    "dijit/form/_FormValueMixin",
    "dijit/form/CurrencyTextBox",
// dgrid
    "dgrid/_StoreMixin",
    "dgrid/Grid",
    "dgrid/editor",
    "dgrid/extensions/DijitRegistry",
// epi
    "epi/shell/dgrid/Focusable",
    "epi/shell/widget/_FocusableMixin",
// epi-ecf-ui
    "./AmountEditor",
// put
     "put-selector/put",
// resources
    "epi/i18n!epi/cms/nls/commerce.widget.moneylisteditor"
], function (
// dojo
    array,
    declare,
    lang,
    aspect,
    currency,
    keys,
    Memory,
    string,
// dijit
    _KeyNavContainer,
    _TemplatedMixin,
    _WidgetBase,
    _FormValueMixin,
    CurrencyTextBox,
// dgrid
    _StoreMixin,
    Grid,
    editor,
    DijitRegistry,
// epi
    Focusable,
    _FocusableMixin,
// epi-ecf-ui
    AmountEditor,
// put
    put,
// resources
    resources
) {

    var MoneyListGrid = declare([Grid, _StoreMixin, DijitRegistry, Focusable], {
        // summary:
        //      dgrid mixin which implements the refresh method to
        //      always perform a single query with no start or count
        //      specified, to retrieve all relevant results at once.
        //      Appropriate for grids using memory stores with small
        //      result set sizes.
        //
        //      based on http://dgrid.io/tutorials/0.3/single_query/
        // tags:
        //      internal

        refresh: function () {
            var self = this;

            // First defer to List#refresh to clear the grid's
            // previous content.
            this.inherited(arguments);

            if (!this.store) {
                return;
            }
            return this._trackError(function () {
                var queryOptions = self.get('queryOptions'),
                    results = self.store.query(
                        self.query, queryOptions);

                return self.renderArray(
                    results, null, queryOptions);
            });
        },

        renderArray: function () {
            var rows = this.inherited(arguments);
            // This will ensure that the noDataMessage is added
            // without the need to call refresh on the grid.
            if (rows && rows.length === 0) {
                this.noDataNode = put(this.contentNode, "div.dgrid-no-data");
                this.noDataNode.innerHTML = this.noDataMessage;
            }
            // Clear _lastCollection which is ordinarily only used for
            // store-less grids.
            this._lastCollection = null;

            return rows;
        }
    });

    return declare([_WidgetBase, _TemplatedMixin, _FocusableMixin, _FormValueMixin, _KeyNavContainer], {
        // summary:
        //      A widget used to edit a list of Money.
        // tags:
        //      internal

        templateString: '<div class="dijitInline"><div data-dojo-attach-point="gridNode,focusNode"></div></div>',

        grid: null,

        value: null,

        _valueStore: null,

        // tabIndex: String
        //      We set tabIndex to -1 so that tabbing moves focus to the inputs in the grid.
        tabIndex: "-1",

        // Override _FormWidgetMixin mapping id to this.focusNode since focus node is also a widget
        // and changing its id will break widget destruction.
        _setIdAttr: "domNode",

        _amountEditors: [],

        postMixInProperties: function () {
            this.inherited(arguments);
            this._valueStore = this._valueStore || new Memory({ idProperty: "currency" });
        },

        postCreate: function () {
            this.inherited(arguments);
            this._setupGrid();
        },

        _getAmountEditorId: function (currencyCode) {
            return string.substitute("${id}_${currencyCode}_editor", { id: this.id, currencyCode: currencyCode });
        },

        _createAmountColumn: function () {
            if (this.readOnly) {
                return {
                    label: resources.amount,
                    sortable: false,
                    className: "epi-grid--50",
                    readOnly: true,
                    formatter: this._amountFormatter
                };
            } else {
                return editor({
                    label: resources.amount,
                    sortable: false,
                    editor: AmountEditor,
                    autoSave: true,
                    canEdit: function (object, value) {
                        this._currency = object.currency;
                        return true;
                    },
                    editorArgs: lang.hitch(this, function (column) {
                        return {
                            id: this._getAmountEditorId(column._currency),
                            className: "epi-grid-column--right dijitInputInner",
                            currency: column._currency
                        };
                    }),
                    className: "epi-grid--50 epi-dgrid--editable"
                });
            }
        },

        _setupGrid: function () {
            var columns = {
                currency: {
                    label: resources.currency,
                    sortable: false,
                    className: "epi-grid--50",
                    formatter: lang.hitch(this, function (value) { return string.substitute("<label for=\"${id}\">${currencyCode}</label>", { id: this._getAmountEditorId(value), currencyCode: value }); })
                },
                amount: this._createAmountColumn()
            };

            this.grid = new MoneyListGrid({
                store: this._valueStore,
                selectionMode: "none",
                noDataMessage: resources.nodatamessage,
                className: "epi-plain-grid epi-grid--with-border epi-grid-height--auto epi-money-grid",
                columns: columns
            }, this.gridNode);

            this.own(
                this.grid,
                aspect.after(this.grid, "save", lang.hitch(this, function () {
                    if (this.isValid()) {
                        // By calling onChange after save we will report correct values
                        // when tabbing between inputs inside the editor.
                        this.onChange(this.get("value"));
                    }
                }))
            );

            this.grid.set("query", {});
        },

        _amountFormatter: function (amount) {
            var displayText = resources.undefinedamount;
            if (amount) {
                displayText = currency.format(amount);
            }
            return displayText;
        },

        _collectAmountEditors: function () {
            // summary:
            // Collect all amount editors in the grid
            // tags:
            //    private
            if (!this.grid) {
                return;
            }

            this._amountEditors.length = 0;
            array.forEach(this._valueStore.data, function (money) {
                var cell = this.grid.cell(money.currency, "amount");
                if (cell && cell.element) {
                    var editor = cell.element.widget;
                    if (editor) {
                        this._amountEditors.push(editor);
                    }
                }
            }, this);

        },

        _setValueAttr: function (value) {
            if (value) {
                this._valueStore.setData(value);
            }
            if (this.grid) {
                this.grid.refresh();
                this._collectAmountEditors();
            }
        },

        _getValueAttr: function () {
            if (!this._valueStore.data.length) {
                return null;
            }
            var newCurrencyValues = this.grid.dirty;
            for (var currencyId in newCurrencyValues) {
                // If we have any dirty data in the grid we need to update it on the store data
                // immediately and not wait for any timeouts set by other widgets or modules.
                // This enables the correct values to be returned when the entire widget is blurred.
                this._updateCurrencyAmountValue(currencyId, newCurrencyValues[currencyId]);
            }
            return this._valueStore.data;
        },

        _updateCurrencyAmountValue: function (currencyId, newCurrencyValue) {
            var currencyAmount = this._valueStore.get(currencyId);
            if (currencyAmount) {
                currencyAmount.amount = newCurrencyValue.amount;
                this._valueStore.put(currencyAmount);
            }
        },

        onChange: function (value) {
            // summary:
            //    Fired when value is changed.
            // tags:
            //    public, callback
        },

        destroy: function () {
            this.inherited(arguments);

            this._amountEditors.length = 0;
        },

        isValid: function () {
            // summary:
            // Editor is valid when and only when all child widgets are valid.
            // tags:
            //    public
            return !array.some(this._amountEditors, function (widget) {
                return !widget.isValid();
            });
        }
    });
});