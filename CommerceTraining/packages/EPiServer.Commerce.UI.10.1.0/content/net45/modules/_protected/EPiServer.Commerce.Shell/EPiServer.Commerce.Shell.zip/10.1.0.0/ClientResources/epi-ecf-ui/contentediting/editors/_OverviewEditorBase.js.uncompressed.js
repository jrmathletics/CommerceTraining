﻿define("epi-ecf-ui/contentediting/editors/_OverviewEditorBase", [
    // Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-construct",
    "dojo/aspect",
    "dojo/Deferred",
    "dojo/Stateful",
    "dojo/when",

    // Dijit
    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",

    // Epi
    "epi/dependency",
    "epi/string",
    "epi/shell/_ContextMixin",
    "epi/shell/widget/_FocusableMixin", 
    "epi/shell/widget/_ModelBindingMixin",
    "epi/shell/widget/dialog/Confirmation",

    //epi-CMS
    "epi-cms/dgrid/formatters"
], function (
    // Dojo
    declare,
    lang,
    domConstruct,
    aspect,
    Deferred,
    Stateful,
    when,

    // Dijit
    _LayoutWidget,
    _TemplatedMixin,

    // Epi
    dependency,
    epiString,
    _ContextMixin,
    _FocusableMixin,
    _ModelBindingMixin,
    Confirmation,

    //epi-CMS
    formatters
) {
    return declare([_LayoutWidget, _TemplatedMixin, _ModelBindingMixin, _FocusableMixin, _ContextMixin], {

        templateString: '<div class="epi-listingOverviewEditor" data-dojo-attach-point="gridNode"></div>',

        postCreate: function () {
            // Get metadata for itemType
            when(this.model.metadataManager.getMetadataForType(this.itemType), lang.hitch(this, function (metadata) {
                // Set up columns object with one column for context menu
                var columns = [{
                    field: "epiGridAction",
                    renderHeaderCell: function () { }, // no header
                    formatter: lang.hitch(this, function () {
                        return formatters.menu({
                            title: this.title
                        });
                    }),
                    className: "epi-columnNarrow",
                    sortable: false
                }],
                store = dependency.resolve("epi.storeregistry").get(this.storeKey),

                editorGridSettings = lang.mixin({
                    selectionMode: "none",
                    store: store,
                    minWidth: 100,
                    noDataMessage: this._noDataMessage,
                    "class": "epi-plain-grid epi-plain-grid--small-header-font",
                    columns: columns,
                    metadata: {
                        properties: metadata.properties,
                        gridIncluded: this.includedColumns,
                        gridEditable: this.editableColumns
                    }
                }, this.additionalEditorGridSettings),

                grid = this.grid = new this.editorGrid(editorGridSettings);

                this.model.generateFormatters(grid.columns, grid.metadata.gridEditable, grid.metadata);
                domConstruct.place(this.grid.domNode, this.gridNode);
                this._setupEvents(grid);

                this._setupContextMenu();

                // Update the grid query in case the contentlink value set but the model or setupEvent hasn't been initialized.
                when(this.getCurrentContext(), lang.hitch(this, function (currentContext) {
                    if (this.model.get("contentLink") !== currentContext.id) {
                        //we're setting the value, since that will update the models content link
                        //which will update the grids query
                        this.set("value", currentContext.id);
                    } else {
                        //the model already has correct contentLink. Here we just make sure
                        //the grid gets the correct query before starting it
                        this._updateGridQuery(grid);
                    }
                    grid.startup();
                    this.own(
                        //we need to wait until after startup to attach to "edit" as that function is created
                        //during startup.
                        aspect.before(grid, "edit", lang.hitch(this, function (cell) {
                            //we save this value to show in the grid while editing in the popup.
                            this.currentEditorHtmlValue = cell.innerHTML;
                        }))
                    );
                }));
            }));
        },

        _updateGridQuery: function (grid) {
            // summary:
            //      update the query for grid.
            //  tags:
            //      private

            var queryOptions = this.model._createQueryOptions();
            grid.set("query", queryOptions.query, queryOptions.options);
        },

        _changeGridQuery: function (property, oldValue, newValue) {
            // summary:
            //      event to update the grid query.
            //  tags:
            //      private

            if (oldValue !== newValue) {
                this._updateGridQuery(this.grid);
            }
        },

        _setupContextMenu: function () {
            this.commands = this.model.getCommands(this.grid, "context");

            this.grid.contextMenu.addProvider(new Stateful({
                commands: this.commands
            }));
        },

        _setValueAttr: function (value) {
            // summary:
            //      Value setter.
            // description:
            //      Push value to the model to be its data.
            //  tags:
            //      private

            this._set("value", value);

            if (this.model) {
                this.model.set("contentLink", value);
            }
        },

        _showConfirmation: function (title, description) {
            // summary:
            //      Wrap epi.shell.widget.dialog.Confirmation for short type
            //      and return deferred object
            // description:
            //      String: Text to display on dialog
            // tags:
            //      private

            var deferred = new Deferred();

            var dialog = new Confirmation({
                destroyOnHide: true,
                title: epiString.toHTML(title),
                description: epiString.toHTML(description),
                onAction: function (confirmed) {
                    if (confirmed) {
                        deferred.resolve();
                    } else {
                        deferred.cancel();
                    }
                }
            });
            dialog.show();

            return deferred.promise;
        },

        resize: function () {
            this.inherited(arguments);
            if (this.grid) {
                this.grid.resize();
            }
        },

        onContextMenuClick: function (e) {
            this.selectedRecord = this.grid.row(e).data;
        }
    });
});