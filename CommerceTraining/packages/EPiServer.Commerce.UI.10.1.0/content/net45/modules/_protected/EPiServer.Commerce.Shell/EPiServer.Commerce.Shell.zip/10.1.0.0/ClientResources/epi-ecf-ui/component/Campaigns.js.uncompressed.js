﻿define("epi-ecf-ui/component/Campaigns", [
// dojo
    "dojo/_base/declare",
// epi cms
    "epi-cms/widget/HierarchicalList"
],

function (
// dojo
    declare,
// epi cms
    HierarchicalList) {
    // module:
    //      epi-ecf-ui.component.Campaigns

    return declare([HierarchicalList], {
        // summary:
        //      Campaigns component.
        // tags:
        //      public

        setupContextMenu: function () {
            // summary: set up the context menu. Overridden to not add context menu on the campaign tree gadget
            //
            // tag:
            //      public override
        }
    });
});